//
//  main.c
//  Calculator (build 01)
//
//  Created by SmileRen on 16/3/25.
//  Copyleft  2016 Smile_Ren_3021. All lefts reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

int main(int argc, const char * argv[])
{
    double n1,n2,add,min,mul,divi,sqr,sqrtout;
    int isodd;
    int test = 2;
    int final = 0;
    char op[15],exit[2];
    printf ("Welcome to use Calculator by Smile_Ren_3021.\nPlease enter add,minus,multiply,divide,sqrt,isodd...\n");
    scanf ("%s",op);
    while (1)
    {
        if (!strcmp(op, "add"))
        {
            printf ("Please enter the first number...\n");
            scanf ("%lf",&n1);
            printf ("Please enter the second number...\n");
            scanf ("%lf",&n2);
            add = n1+n2;
            printf ("%lf+%lf=%lf\n",n1,n2,add);
        }
        if (!strcmp(op, "minus"))
        {
            printf ("Please enter the first number...\n");
            scanf ("%lf",&n1);
            printf ("Please enter the second number...\n");
            scanf ("%lf",&n2);
            min = n1-n2;
            printf ("%lf-%lf=%lf\n",n1,n2,min);
        }
        if (!strcmp(op, "multiply"))
        {
            printf ("Please enter the first number...\n");
            scanf ("%lf",&n1);
            printf ("Please enter the second number...\n");
            scanf ("%lf",&n2);
            mul = n1*n2;
            printf ("%lf*%lf=%lf\n",n1,n2,mul);
        }
        if (!strcmp(op, "divide"))
        {
            printf ("Please enter the first number...\n");
            scanf ("%lf",&n1);
            printf ("Please enter the second number...\n");
            scanf ("%lf",&n2);
            divi = n1/n2;
            printf ("%lf/%lf=%lf\n",n1,n2,divi);
        }
        if (!strcmp(op, "sqrt"))
        {
            printf ("Please enter the number...\n");
            scanf ("%lf",&sqr);
            sqrtout = sqrt(sqr);
            printf ("sqrt %lf = %lf\n",sqr,sqrtout);
        }
        if (!strcmp(op, "isodd"))
        {
            printf ("Please enter a number you want to check...\n");
            scanf ("%d",&isodd);
            if (isodd<=1)
            {
                printf ("You shoudn't enter a number less than 2!\n");
            }
            else
            {
                for (test=2;test<isodd;test++)
                {
                    if (isodd%test == 0)
                    {
                        final = 1;
                    }
                }
                if (final == 0)
                {
                    printf ("%d is an odd number.\n",isodd);
                }
                else
                {
                    printf ("%d is an even number.\n",isodd);
                }
            }
        }
        if (   strcmp (op,"add")
            && strcmp (op,"minus")
            && strcmp (op,"multiply")
            && strcmp (op,"divide")
            && strcmp (op,"sqrt")
            && strcmp (op,"isodd")
            )
        {
            printf ("You have enter the worong key word.\n");
        }
        printf ("-----------------------------------------\nDo you want to exit?(y/n)...\n");
        scanf ("%s",exit);
        if (!strcmp(exit,"y"))
        {
            break;
        }
        else if (!strcmp(exit,"n"))
        {
            printf ("-----------------------------------------\nWelcome to use Calculator by Smile_Ren_3021.\nPlease enter add,minus,multiply,divide,sqrt,isodd,degsine,degcosine,degtangent,degcotangent,radsine,radcosine,radtangent,radcotangent,times,factor or power...\n");
            scanf ("%s",op);
        }
    }
    return 0;
}
